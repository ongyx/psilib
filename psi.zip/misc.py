"""
Contains miscellanious functions
(i.e, help, credits).
"""
from .utils import ansi
from .config import psiman_ver, pyver, c_ver, pyimp

def help():
    print("""
    \nPrinting help...
    \n\n-PACKAGE MANAGEMENT-\n
    \t[-i], {package}: Install new packages.
    \t[-r], {package}: Remove specified package.
    \t[-l], <repo/lcl>: List packages in repo/installed packages.
    \t[-d], {package}: Print description of package specified(if any).
    \n-REPOSITORY MANAGEMENT-\n
    \t[-ar], {repo}: Adds new repository.
    \t[-sr]: Sets main repository to use.
    \t[-dr]: Removes repository from local list.
    \t[-f]: Fetch latest index file from main repository.
    \n-MISCELLANEOUS-\n
    \t[-init], <repo/pkg>: Restores repo to defaults/deletes\n\tall spkg-installed packages(wip).
    \t[-h]: Prints help screen.
    \t[-c]: Print version and credits.\n
    """)

def credits():
    print(ansi(32, bold=True) + '\n\t\t-|Python Script Index MANager|-\nVersion: ' + ansi(36) + psiman_ver + ansi(32, bold=True) + '\nRunning on Python ' + ansi(36) + pyver + ansi(32, bold=True) + '\nPython implementation: ' + ansi(36) + pyimp + ansi(32, bold=True)+ '\nCompiled with ' + ansi(36) + c_ver + ansi(0) + '.\nOrginal code copyright Ong Yong Xin, 2019.\n(Code licensed under MIT License.)\n\nSource code avaliable at https://github.com/sn3ksoftware/psiman.\nThe full MIT license is at ~/Documents/.psicfg/LICENSE.\n')
