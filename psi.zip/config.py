"""
This file is meant to store psiman-specifc
configuration and other constants.
"""
import os
import sys
import platform

# Returns 2-list of (absolute) psicfg and
# script path according to enviroment.

def getPath():
    site_path = next(p for p in sys.path if "site-packages" in p)
    app_path = os.path.expanduser("~") + "/"
    try:
        import objc_util
    except ImportError:
        # not Pythonista, assumes LibTerm for now.
        psicfg_path = site_path + "/psi/cfg"
        script_store = app_path + "Library/scripts/"
        paths = [psicfg_path, script_store]
        return paths
    else:
        # on pythonista.
        psicfg_path = site_path + "/psi/cfg"
        script_store = app_path + "Documents/bin/"
        paths = [psicfg_path, script_store]
        return paths

psiman_ver = '3.0.0a'
psicfg_path = getPath()[0]
script_store = getPath()[1]

# Get Python/c compiler version.
pyver = platform.python_version()
c_ver = platform.python_compiler()
pyimp = platform.python_implementation()
