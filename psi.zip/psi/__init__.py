#!/usr/bin/env python3

"""
psimodule (Python Script Index MANager in
module form.)
Alpha (testing)
(psiman-3.0.0a_universal)
By Ong Yong Xin (Copyright 2019)
Code licensed under MIT License.
Source:
https://github.com/sn3ksoftware/psiman
"""
name = "psimodule"
__author__ = "Ong Yong Xin"
__version__ = "3.0.0-alpha"

# Import local utils and psi functions.
from .misc import help, credits
from .utils import is_number, split, ansi, checkurl
from .repo import add, set, rem
from .package import install, remove, list

# Import external dependencies

from .external import semver
