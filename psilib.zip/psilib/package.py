"""
Contains functions to handle packages
(install, remove, and list packages).
Throws custom exceptions if not sucrssful
(see ./exceptions.py)
"""

# Get global variables and exceptions
# (config.py):
from .config import psicfg_path, script_store
from .exceptions import NoInternet, PackageNoExists, PackageNotInRepo, InvalidJSON, NullInput, RepoNoExists, RepolistMissing

# Import modules (local)
from .utils import ansi

# Import modules (stdlib)
import os
import json
import requests
import glob
from zipfile import ZipFile

"""
Installs packages from the main index to
the script path (psi.config.script_store).
Returns True if sucessful.
"""
def install(pkg_name):
    # Get rid of spaces in package name
    package = pkg_name.replace(" ", "")
    # Get json list of repo
    # Get download url from json listing
    jsonfile = psicfg_path + "/json/index.json"
    with open(jsonfile, 'r') as f:
        json_content = json.load(f)
    try:
        pkg_url = json_content["scripts"][package]["meta_url"]
    except KeyError:
        raise PackageNotInRepo
    else:
        try:
            pkg_infofile = requests.get(pkg_url, allow_redirects=True)
        except requests.exceptions.ConnectionError:
            raise NoInternet
        else:
            # Save package json info as file
            with open(psicfg_path + "/json/"
+ package + ".json", "wb") as f:
                f.write(pkg_infofile.content)
            if pkg_infofile:
                pkg_infofile_p = json.loads(pkg_infofile.content.decode("ascii"))
                # Get url from pkg json file
                pkg_versions = sorted(pkg_infofile_p["releases"], reverse=True)
                # Get latest version of package (highest sorted version number)
                pkg_latest_version = pkg_versions[0]
                try:
                    url = pkg_infofile_p["releases"][pkg_latest_version]["url"]
                except KeyError:
                    raise InvalidJSON("Package has no valid download url.")
                else:
                    # Get package and save it.
                    pkgfile = requests.get(url)
                    if pkgfile:
                        # Write download to temp folder.
                        pkgfile_p = psicfg_path + "/tmp/" + package + ".zip"
                        open(pkgfile_p, 'a').close()
                        with open(pkgfile_p, "wb") as f:
                            f.write(pkgfile.content)
                        # Extract package to script folder
                        zf = ZipFile(pkgfile_p, 'r')
                        zf.extractall(path=script_store)
                        # Remove package to save space.
                        os.remove(pkgfile_p)
                        return True
                    elif pkgfile.status_code == 404:
                        raise NoInternet
            elif pkg_infofile.status_code == 404:
                raise NoInternet

"""
Removes packages in local.
Returns True if sucessful, false if there
was a error removing a existing package.
(Maybe a permissions error?)
"""
def remove(pkg_name):
    # Remove spaces.
    package = pkg_name.replace(" ", "")
    script_d = script_store + package + ".py"
    if os.path.exists(script_d):
        try:
            os.remove(script_d)
        except OSError:
            return False
        else:
            return True
    else:
        raise PackageNoExists

"""
Returns a list of the names of the packages,
either in local or in the repo.
(Local script folder is in
<psi.config.script_store>)
"""
def list(switch):
    if switch == "repo":
        # Get json file containing list of all packages in repo folder
        jsonfile = psicfg_path + '/json/index.json'
        getrepo_r = open(psicfg_path + '/repo/repolist.json', 'r')        
        getrepo_f = json.load(getrepo_r)
        url = getrepo_f["mainrepo"]
        # Take only the username and reponame.
        # Actual downloading and getting dictonary out of serialized json.
        try:
            json_content_r = requests.get(url)
        except requests.exceptions.ConnectionError:
            raise NoInternet
        else:
            json_content = json_content_r.json()
            url_stat = json_content_r.status_code
            if json_content:
                # If URL is valid, grab json listing of repo and cache it.
                with open(jsonfile, "w") as f_w:
                    json.dump(json_content, f_w)
                # Read the dictionary and use to get package names.
                # Tries to read all values with key 'name' until IndexError.
                repolist = []
                try:
                    for key in json_content["scripts"]:
                        repolist.append(key)
                except KeyError:
                    raise RepoNoExists
                else:
                    repolist.sort(key=str.lower)
                    return repolist
            # If url returned 404, tell user to use another repo.
            elif url_stat == 404:
                raise NoInternet
    elif switch == "lcl":
        # List all files with extention .py:
        filenme = [f for f in glob.glob(script_store + "*.py")]
        filenme.sort(key=str.lower)
        filenme_p = []
        for x in filenme:
            if x.endswith(".py"):
                x_r = x.replace(script_store, "")
                x_p = x_r.replace(".py", "")
                filenme_p.append(x_p)
        return filenme_p
    else:
        raise NullInput

"""
Get infomation metadata on a package.
Will return a dictionary of metadata on the
package.
"""
def desc(pkg_name):
    # Get rid of spaces in package name
    package = pkg_name.replace(" ", "")
    # Get json list of repo
    # Get download url from json listing
    jsonfile = psicfg_path + "/json/index.json"
    if os.path.isfile(jsonfile) == True:
        with open(jsonfile, 'r') as f:
            json_content = json.load(f)
            try:
                pkg_url = json_content["scripts"][package]["meta_url"]
            except KeyError:
                raise PackageNoExists
            else:
                pkg_infofile = requests.get(pkg_url, allow_redirects=True)
                # Save package json info as file
                with open(psicfg_path + "/json/"
+ package + ".json", "wb") as f:
                    f.write(pkg_infofile.content)
                if pkg_infofile:
                    pkg_info = json.loads(pkg_infofile.content.decode("ascii"))
                    # Get desc from pkg json file
                    return pkg_info
                else:
                    raise NoInternet
    else:
        raise RepolistMissing("index.json does not exist. Run psi.package.fetch()")
