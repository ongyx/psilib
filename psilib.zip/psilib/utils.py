"""
------------------
***psilib.utils***
------------------
Utilities for psilib.
Might be useful for other programs(???)
"""

"""
Check if string is a number.
Copied from [https://stackoverflow.com/q/354038].
"""
def is_number(str_w_num):
    try:
        float(str_w_num)
        return True
    except ValueError:
        return False

"""
Splits strings more precisely.
Copied from [https://stackoverflow.com/a/52008134].
"""
def split(strng, sep, pos):
    strng = strng.split(sep)
    return sep.join(strng[:pos]), sep.join(strng[pos:])

"""
ANSI Colours for printing (Because why not?)
Code can be 30-37. In order of colours, these are black, red, green, yellow,
blue, magnenta, cyan, and white.
After every colour print, print ansi(0) to clear colour attributes.
"""
def ansi(code_r, bold=""):
    ansi_base = "\033"
    code = str(code_r)
    if bold:
        ansi_code = ansi_base + "[" + code + ";1m"
        return ansi_code
    else:
        ansi_code = ansi_base + "[" + code + "m"
        return ansi_code

"""
Checks if url is a vaild platform (Github, Google Drive, Dropbox)
If so, return True and the direct url to index.json.
"""
def checkurl(url):
    # Import urllib
    import urllib.parse as urlparse
    # Split url to list.
    url_list = urlparse.urlsplit(url)
    wloc = url_list.netloc
    wpath = url_list.path
    # Check for supported websites.
    if wloc == "drive.google.com":
        url_base = "https://drive.google.com/uc?export=download&id="
        # Strip file id from path
        wlist = wpath.split("/")
        id = wlist[3]
        url_p = url_base + id
        return True, url_p
    elif wloc == "www.dropbox.com":
        # Strip file id from path
        wlist = wpath.split("/")
        id = wlist[2]
        url_p = "https://dl.dropbox.com/s/" + id + "/index.json?dl=1"
        return True, url_p
    elif wloc == "raw.githubusercontent.com":
        return True, url
    else:
        return False, None
"""
---------------------------
***END SPECIAL FUNCTIONS***
---------------------------
"""
