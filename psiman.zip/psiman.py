# psiman (Python Script Index MANager)
# Alpha (Testing Branch)
# (psiman-2.00a_libterm)
# By Ong Yong Xin (Copyright 2019)
# Code licensed under MIT License.

# Import needed modules.
import sys, os, subprocess, json, requests, glob
from pathlib import Path
from zipfile import ZipFile

# If there are no arguements, provide user help
def getParameters(args):
    if len(args) == 1:
        print('\nusage: psiman [action] <options>\nType [psiman -h] for help.')
    else:
        arg1_raw = (sys.argv[1])
        return(arg1_raw)

# Get first arguement from params
arg1 = getParameters(sys.argv)
argall = sys.argv

# Declare global args.
# Feedback text is stored here for easier debugging.
psiman_ver = '2.00a'
libterm_path = os.path.expanduser('~') + '/'
term_rows = int(float(os.getenv("ROWS")))
term_columns = int(float(os.getenv("COLUMNS")))

# Get Python/c compiler version.
version_raw = sys.version
pyver = version_raw[0:5]
c_ver = version_raw.splitlines()[1]

helptxt = '\nPrinting help...\n\n-PACKAGE MANAGEMENT-\n\n✓[-i], [package]: Install new packages.\n✓[-r], [package]: Remove specified package.\n✓[-l], [repo/lcl]: List packages in repo/installed packages.\n ✓[-d], [package]: Print description of package specified(if any).\n\n-REPOSITORY MANAGEMENT-\n\n✓[-ar], [repo]: Adds new repository.\n✓[-sr]: Sets main repository to use.\n✓[-dr]: Removes repository from local list.\n\n-MISCELLANEOUS-\n\n[-init], <repo/pkg>: Restores repo to defaults/deletes all spkg-installed packages(wip).\n✓[-h]: Prints help screen.\n✓[-c]: Print version and credits.\nNB: All options with [✓] are functional. Any other options may be buggy or unusuable.\n'
creditstxt = '\n\t\t-|Python Script Index MANager|-\nVersion: ' + psiman_ver + '\n(Alpha, Testing)\nRunning on Python ' + pyver + '\nCompiled with ' + c_ver + '.\nOrginal code ©Ong Yong Xin, 2019.\n(Code licensed under MIT License.)\n\nSource code avaliable at https://github.com/sn3ksoftware/psiman.\nThe full MIT license is at ~/.psicfg/LICENSE.\n'
wiptxt = '\nThis feature is work in progress, please be patient for the next update.\n'
initxt = '\nW: Are you sure you want to initalize'

# ERRORS
no_internet = 'E: No internet connection/Object not found.\n(Is the server down?)'
null_input = 'Invalid input.\nAbort.'
invalid_cmd = '\nE: Invalid/unknown command. Try again.\n\nusage: psiman [options]\nType [spkg -h] for help.\n '
null_addedrepo = '\nE: No repo specified. Try again.\nusage: psiman -ar <repo>\n'
null_inspkg = '\nE: No package specified. Try again.\nusage: psiman -i <package>\n'
null_rmpkg = '\nE: No package specifed. Try again.\nusage: psiman -r <package>\n'
null_init = '\nE: No init option specified. Try again.\nusage: psiman -init <repo/pkg>\n'
null_listpkg = '\nE: No list option specified. Try again.\nusage: psiman -l <repo/lcl>'
null_descpkg = 'E: No package specified. Try again.\nusage: psiman -d <package>'

# ***SPECIAL FUNCTIONS***
# Global functions for this script are stored here.

# Define checkisnumber function
def is_number(str_w_num):
    try:
        float(str_w_num)
        return True
    except ValueError:
        return False

# Define split function.
def split(strng, sep, pos):
    strng = strng.split(sep)
    return sep.join(strng[:pos]), sep.join(strng[pos:])

# ***END SPECIAL FUNCTIONS***

# Define addrepo option
def addrepo():
    if len(sys.argv) == 2:
        print(null_addedrepo)
    else:
        arg2 = argall[2]
        repo = arg2[19:-4]
        branch_choice = input("\nInput the name of the branch used.\nPress return for default branch [master].\n(DON'T PUT SPACING.)\n>>> ")
        # Remove spaces in case.
        branch_choice.replace(" ","")
        if branch_choice == '':
            print('Master branch chosen.')
            print('\nAdding repo ' + repo + ' to repofile...')
            # Build Github repo url.
            gitRepoURL = 'https://raw.githubusercontent.com/' + repo + '/master/index.json'
            repolist_f = open(libterm_path + "Documents/.psicfg/repo/repolist.json", "r")
            repolist_json = json.load(repolist_f)
            mainrepo_j = repolist_json["mainrepo"]
            repolist_p = repolist_json["repolist"]
            repolist_p.append(gitRepoURL)
            # Build dictionary to serialize into json
            # Just adds to current list of repos.
            repodict = dict({"mainrepo": mainrepo_j, "repolist": repolist_p})
            repolist_f = open(libterm_path + "Documents/.psicfg/repo/repolist.json", "w")
            json.dump(repodict, repolist_f)
            print("\nDone.")
        else:
            print('\n' + branch_choice + ' branch chosen.')
            print('\nAdding repo ' + repo + ' to repofile...')
            gitRepoURL = 'https://raw.githubusercontent.com/' + repo + '/' + branch_choice + '/index.json'
            repolist_f = open(libterm_path + "Documents/.psicfg/repo/repolist.json", "r")
            repolist_json = json.load(repolist_f)
            mainrepo_j = repolist_json["mainrepo"]
            repolist_p = repolist_json["repolist"]
            repolist_p.append(gitRepoURL)
            # Build dictionary to serialize into json
            # Just adds to current list of repos.
            repodict = dict({"mainrepo": mainrepo_j, "repolist": repolist_p})
            repolist_f = open(libterm_path + "Documents/.psicfg/repo/repolist.json", "w")
            json.dump(repodict, repolist_f)
            print("\nDone.")

# Define setrepo option
def setrepo():
    print('\nHere is a list of all the repos:\n')
    repolist_f = open(libterm_path + 'Documents/.psicfg/repo/repolist.json', 'r')
    repolist_json = json.load(repolist_f)
    repolist_p = repolist_json["repolist"]
    repo_counter = 1
    for i in repolist_p:
        print(str(repo_counter) + ": " + i)
        repo_counter += 1
    mainrepo_c_raw = input("\nSelect the main repository to use (by number):\n>>> ")
    # Remove spaces in case.
    mainrepo_c_raw.replace(" ","")
    # Check if input is actually a number
    if is_number(mainrepo_c_raw) == False:
        print(null_input)
    else:
        # Derive interger from input.
        mainrepo_c = int(float(mainrepo_c_raw))
        # Get line count for repolist.
        lineCount = len(repolist_p)
        # Check for invalid input.
        # (i.e, line 0)
        if mainrepo_c == "0":
            print(null_input)
        elif mainrepo_c > lineCount:
            print(null_input)
        else:
            # Get repo url.
            # Get choice minus 1 because list counting starts at 0
            mainrepo_c = mainrepo_c - 1
            mainrepo_curl = repolist_p[mainrepo_c]
            print("\nSetting " + mainrepo_curl + " as main repository.\n")
            mainrepo_dict = dict({"mainrepo": mainrepo_curl, "repolist": repolist_p})
            with open(libterm_path + 'Documents/.psicfg/repo/repolist.json', 'w') as f: 
                json.dump(mainrepo_dict, f)
            print("Done.")
        
# Define deleterepo option
def delrepo():
    print('\nHere is a list of all the repos:\n')
    repolist_f = open(libterm_path + 'Documents/.psicfg/repo/repolist.json', 'r')
    repolist_json = json.load(repolist_f)
    repolist_p = repolist_json["repolist"]
    repolist_m = repolist_json["mainrepo"]
    repo_counter = 1
    for i in repolist_p:
        print(str(repo_counter) + ": " + i)
        repo_counter += 1
    delrepo_c_raw = input("\nSelect the repository to delete (by number):\n>>> ")
    # Remove spaces in case.
    delrepo_c_raw.replace(" ","")
    # Check if input is actually a number
    if is_number(delrepo_c_raw) == False:
        print(null_input)
    else:
        # Derive interger from input.
        delrepo_c = int(float(delrepo_c_raw))
        # Get line count for repolist.
        lineCount = len(repolist_p)
        # Check for invalid input.
        # (i.e, line 0)
        if delrepo_c == "0":
            print(null_input)
        elif delrepo_c > lineCount:
            print(null_input)
        else:
            # Get choice minus 1 because list counting starts at 0
            delrepo_c = delrepo_c - 1
            delrepo_curl = repolist_p[delrepo_c]
            print("\nDeleting " + delrepo_curl + "...\n")
            # Delete url chosen and write back to json file
            del repolist_p[delrepo_c]
            delrepo_dict = dict({"mainrepo": repolist_m, "repolist": repolist_p})
            with open(libterm_path + 'Documents/.psicfg/repo/repolist.json', 'w') as f: 
                json.dump(delrepo_dict, f)
            print("Done.")

# Define install function.
def installpkg():
    if len(sys.argv) == 2:
        print(null_inspkg)
    else:
        # Get rid of spaces in package name
        package_r = sys.argv[2]
        package = package_r.replace(" ", "")
        print("\nFinding package " + package + "...")
        # Get json list of repo
        # Get download url from json listing
        jsonfile = libterm_path + "Documents/.psicfg/json/index.json"
        with open(jsonfile, 'r') as f:
            json_content = json.load(f)
            try:
                pkg_url = json_content["scripts"][package]["meta_url"]
            except KeyError:
                print("\nE: Package not found, nothing installed.")
            else:
                print("\nSuccess! Package found.\nGetting pkg info...")
                pkg_infofile = requests.get(pkg_url, allow_redirects=True)
                # Save package json info as file
                with open(libterm_path + "Documents/.psicfg/json/"
+ package + ".json", "wb") as f:
                    f.write(pkg_infofile.content)
                if pkg_infofile:
                    pkg_infofile_p = json.loads(pkg_infofile.content)
                    # Get url from pkg json file
                    pkg_versions = sorted(pkg_infofile_p["releases"], reverse=True)
                    # Get latest version of package (highest sorted version number)
                    pkg_latest_version = pkg_versions[0]
                    try:
                        url = pkg_infofile_p["releases"][pkg_latest_version]["url"]
                    except KeyError:
                        print("\nE: No vaild download url for package found! Make sure that the json info is set correctly!")
                    else:
                        # Get package and save it.
                        pkgfile = requests.get(url)
                        if pkgfile:
                            # Write download to temp folder.
                            pkgfile_p = libterm_path + "Documents/.psicfg/tmp/" + package + ".zip"
                            Path(pkgfile_p).touch()
                            with open(pkgfile_p, "wb") as f:
                                f.write(pkgfile.content)
                            print("\nInstalling " + package + "...")
                            # Extract package to script folder
                            zf = ZipFile(pkgfile_p, 'r')
                            scriptfolder = libterm_path + "Library/scripts"
                            zf.extractall(path=scriptfolder)
                            # Remove package to save space.
                            os.remove(pkgfile_p)
                            print("\nDone.")
                        elif pkgfile == 404:
                            print(no_internet)
                elif pkg_infofile == 404:
                    print(no_internet)

# Define removepkg function.
def removepkg():
    if len(sys.argv) == 2:
        print(null_rmpkg)
    else:
        # Remove spaces.
        arg2_r = sys.argv[2]
        arg2 = arg2_r.replace(" ", "")
        script_d = libterm_path + "Library/scripts/" + arg2 + ".py"
        if os.path.exists(script_d):
            os.remove(script_d)
            print("\nDeleted " + arg2 + ".\n")
        else:
            print("\nE: Script to be deleted does not exist!")

# Define listpkg function.
def listpkg():
    if len(sys.argv) == 2:
        print(null_listpkg)
    else:
        if sys.argv[2] == "repo":
            print("\nPinging repo server...")
            # Get json file containing list of all packages in repo folder
            jsonfile = libterm_path + 'Documents/.psicfg/json/index.json'
            getrepo_r = open(libterm_path + 'Documents/.psicfg/repo/repolist.json', 'r')
            getrepo_f = json.load(getrepo_r)
            url = getrepo_f["mainrepo"]
            # Take only the username and reponame.
            # Actual downloading and getting dictonary out of serialized json.
            json_content_r = requests.get(url)
            json_content = json_content_r.json()
            url_stat = json_content_r.status_code
            if json_content:
                print('\nSucess!\nResponse code is ' + str(url_stat))
                # If URL is valid, grab json listing of repo and cache it.
                with open(jsonfile, "w") as f_w:
                    json.dump(json_content, f_w)
                # Read the dictionary and use to get package names.
                # Tries to read all values with key 'name' until IndexError.
                print("\nListing...\n")
                try:
                    for key in json_content["scripts"]:
                        print(key)
                except KeyError:
                    print("\nE: File listing of repo failed.\n(Does it actually exist?")
                else:
                    print("\nDone.")
            # If url returned 404, tell user to use another repo.
            elif url_stat == 404:
                print(no_internet)
        elif sys.argv[2] == "lcl":
            script_p = libterm_path + "Library/scripts/"
            # List all files with extention .py:
            filenme = [f for f in glob.glob(script_p + "*.py")]
            filenme.sort(key=str.lower)
            print("\nListing...\n")
            for x in filenme:
                x_r = x.replace(script_p, "")
                x_p = x_r.replace(".py", "")
                print(x_p)
            print("\nDone.")

# Define initall function.
def initall():
    if len(sys.argv) == 2:
        print(null_init)
    else:
        arg2 = sys.argv[2]
        if arg2 == 'repo':
            print("\nOverwriting repolist and mainrepo to defaults...")
            repo_dict = {
                "mainrepo": "https://raw.githubusercontent.com/sn3ksoftware/sandboxrepo/master/libterm",
                "repolist": ["https://raw.githubusercontent.com/sn3ksoftware/sandboxrepo/master/libterm"]
            }
            with open(libterm_path + "Documents/.psicfg/repo/repolist.json", "w") as f:
                json.dump(repo_dict, f)
            print("\nDone.")
        elif arg2 == 'pkg':
            print(wiptxt)

# Define description function.
# Code is almost the same as installpkg().
def desc():
    if len(sys.argv) == 2:
        print(null_descpkg)
    else:
        # Get rid of spaces in package name
        package_r = sys.argv[2]
        package = package_r.replace(" ", "")
        print("\nFinding description of " + package + "...")
        # Get json list of repo
        # Get download url from json listing
        jsonfile = libterm_path + "Documents/.psicfg/json/index.json"
        with open(jsonfile, 'r') as f:
            json_content = json.load(f)
            try:
                pkg_url = json_content["scripts"][package]["meta_url"]
            except KeyError:
                print("\nE: Package not found, entry does not exist!")
            else:
                print("\nSuccess! Package found.\nGetting pkg info...")
                pkg_infofile = requests.get(pkg_url, allow_redirects=True)
                # Save package json info as file
                with open(libterm_path + "Documents/.psicfg/json/"
+ package + ".json", "wb") as f:
                    f.write(pkg_infofile.content)
                if pkg_infofile:
                    pkg_info = json.loads(pkg_infofile.content)
                    # Get desc from pkg json file
                    print("\n")
                    for key,val in pkg_info.items():
                        print(key, ":", val)
                    print("\n")
                else:
                    print(no_internet)

# Define main function.

def main():
    if arg1 == '-h':
        print(helptxt)
    elif arg1 == '-c':
        print(creditstxt)
    elif arg1 == '-ar':
        addrepo()
    elif arg1 == '-sr':
        setrepo()
    elif arg1 == '-dr':
        delrepo()
    elif arg1 == '-i':
        installpkg()
    elif arg1 == '-r':
        removepkg()
    elif arg1 == '-l':
        listpkg()
    elif arg1 == '-init':
        initall()
    elif arg1 == '-d':
        desc()
    elif len(sys.argv) == 1:
        print("")
    else:
        print(invalid_cmd)

# Standard boilerplate to call the main() function to begin
# the program.
if __name__ == '__main__':
    main()